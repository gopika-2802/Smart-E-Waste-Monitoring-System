
import React, { useState } from 'react';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { auth, db } from '../firebase/firebaseConfig';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { useNavigate, Link } from 'react-router-dom';

export default function Signup(){
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  // Important: signups always create role = 'user'. Admin must promote users.
  const handle = async (e) => {
    e.preventDefault();
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, password);
      const uid = cred.user.uid;
      await setDoc(doc(db, 'users', uid), {
        uid,
        name,
        email,
        phone,
        role: 'user',
        createdAt: serverTimestamp()
      });
      alert('Signup successful. Please login.');
      navigate('/');
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <form onSubmit={handle} className="bg-white p-8 rounded-lg shadow-md w-96">
        <h2 className="text-2xl font-bold mb-4 text-green-600">Signup</h2>
        <input className="w-full mb-3 p-2 border rounded" placeholder="Name" value={name} onChange={e=>setName(e.target.value)} required />
        <input className="w-full mb-3 p-2 border rounded" placeholder="Email" type="email" value={email} onChange={e=>setEmail(e.target.value)} required />
        <input className="w-full mb-3 p-2 border rounded" placeholder="Phone" value={phone} onChange={e=>setPhone(e.target.value)} required />
        <input className="w-full mb-3 p-2 border rounded" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} required />
        <p className="text-sm text-gray-600 mb-3">Note: Role will be <strong>user</strong>. Admin can later promote to pickup/admin.</p>
        <button className="w-full bg-green-600 text-white py-2 rounded">Create account</button>
        <p className="mt-3 text-sm">Already have account? <Link to="/" className="text-green-600">Login</Link></p>
      </form>
    </div>
  );
}
