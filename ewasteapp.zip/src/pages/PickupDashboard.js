
import React, { useEffect, useState } from 'react';
import { query, collection, where, onSnapshot, doc, updateDoc } from 'firebase/firestore';
import { db, auth } from '../firebase/firebaseConfig';
import { onAuthStateChanged, signOut } from 'firebase/auth';

export default function PickupDashboard(){
  const [jobs, setJobs] = useState([]);
  const [userId, setUserId] = useState(null);

  useEffect(()=>{
    const unsubAuth = onAuthStateChanged(auth, (u)=> {
      setUserId(u ? u.uid : null);
    });
    return unsubAuth;
  }, []);

  useEffect(()=>{
    if (!userId) return;
    const q = query(collection(db, 'ewasteSubmissions'), where('pickupPersonId', '==', userId));
    const unsub = onSnapshot(q, (snap)=>{
      setJobs(snap.docs.map(d=> ({ id: d.id, ...d.data() })));
    });
    return unsub;
  }, [userId]);

  const markCollected = async (id) => {
    await updateDoc(doc(db, 'ewasteSubmissions', id), { status: 'Collected' });
    alert('Marked collected');
  };

  const handleLogout = async ()=> {
    await signOut(auth);
    window.location.href = '/';
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Pickup Dashboard</h1>
        <button onClick={handleLogout} className="bg-red-500 text-white px-4 py-2 rounded">Logout</button>
      </div>

      {jobs.length === 0 ? <p>No assigned tasks</p> : jobs.map(j=>(
        <div key={j.id} className="bg-white p-4 rounded shadow mb-3">
          <p><strong>User:</strong> {j.email}</p>
          <p><strong>Type:</strong> {j.ewasteType}</p>
          <p><strong>Quantity:</strong> {j.quantity}</p>
          <p><strong>Address:</strong> {j.address}</p>
          <p><strong>Phone:</strong> <a href={`tel:${j.phone}`} className="text-blue-600">{j.phone}</a></p>
          <p><strong>Status:</strong> {j.status}</p>
          {j.status !== 'Collected' && <button className="mt-2 bg-green-600 text-white px-3 py-1 rounded" onClick={()=>markCollected(j.id)}>Mark Collected</button>}
        </div>
      ))}
    </div>
  );
}
