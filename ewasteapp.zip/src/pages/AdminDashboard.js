
import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, query, where, doc, updateDoc, getDocs } from 'firebase/firestore';
import { db, auth } from '../firebase/firebaseConfig';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import AdminAnalytics from './AdminAnalytics';

export default function AdminDashboard(){
  const [ewastes, setEwastes] = useState([]);
  const [pickupPersons, setPickupPersons] = useState([]);
  const [users, setUsers] = useState([]);
  const [adminId, setAdminId] = useState(null);

  useEffect(()=>{
    const unsubAuth = onAuthStateChanged(auth, (u)=> setAdminId(u?u.uid:null));
    return unsubAuth;
  }, []);

  useEffect(()=>{
    const unsubE = onSnapshot(collection(db, 'ewasteSubmissions'), (snap)=> setEwastes(snap.docs.map(d=> ({ id: d.id, ...d.data() }))));
    const q = query(collection(db, 'users'), where('role', '==', 'pickup'));
    const unsubP = onSnapshot(q, (snap)=> setPickupPersons(snap.docs.map(d=> ({ id: d.id, ...d.data() }))));
    // load all users for promotion
    const loadUsers = async ()=> {
      const all = await getDocs(collection(db, 'users'));
      setUsers(all.docs.map(d=> ({ id: d.id, ...d.data() })));
    };
    loadUsers();
    return ()=> { unsubE(); unsubP(); };
  }, []);

  const assignPickup = async (ewasteId, pickupId, pickupName) => {
    await updateDoc(doc(db, 'ewasteSubmissions', ewasteId), {
      pickupPersonId: pickupId,
      pickupPersonName: pickupName,
      status: 'Assigned'
    });
    alert('Assigned');
  };

  const promoteUser = async (uid, newRole) => {
    await updateDoc(doc(db, 'users', uid), { role: newRole });
    alert('Role updated');
  };

  const handleLogout = async ()=> { await signOut(auth); window.location.href = '/'; };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Admin Dashboard</h1>
        <button onClick={handleLogout} className="bg-red-500 text-white px-4 py-2 rounded">Logout</button>
      </div>

      <section className="mb-6">
        <h2 className="text-xl font-semibold mb-2">E-Waste Submissions</h2>
        {ewastes.length === 0 ? <p>No submissions</p> : ewastes.map(e=>(
          <div key={e.id} className="bg-white p-3 rounded shadow mb-2">
            <p><strong>User:</strong> {e.email}</p>
            <p><strong>Type:</strong> {e.ewasteType}</p>
            <p><strong>Qty:</strong> {e.quantity}</p>
            <p><strong>Phone:</strong> {e.phone}</p>
            <p><strong>Status:</strong> {e.status}</p>
            {e.status === 'Pending' && (
              <select className="mt-2 p-2 border" onChange={(ev)=>{
                const val = ev.target.value; if(!val) return;
                const [pid, pname] = val.split('||');
                assignPickup(e.id, pid, pname);
              }}>
                <option value="">Assign pickup</option>
                {pickupPersons.map(p=> <option key={p.id} value={`${p.id}||${p.name||p.email}`}>{p.name||p.email}</option>)}
              </select>
            )}
          </div>
        ))}
      </section>

      <section className="mb-6">
        <h2 className="text-xl font-semibold mb-2">User Management (Promote)</h2>
        <p className="text-sm mb-2">Promote a user to pickup or admin. Signup always creates a <code>user</code> role.</p>
        {users.map(u=>(
          <div key={u.id} className="bg-white p-3 rounded shadow mb-2 flex items-center justify-between">
            <div>
              <p className="font-medium">{u.name || u.email}</p>
              <p className="text-sm text-gray-600">{u.email} • role: {u.role}</p>
            </div>
            <div className="flex gap-2">
              {u.role !== 'pickup' && <button className="px-3 py-1 bg-blue-600 text-white rounded" onClick={()=>promoteUser(u.id, 'pickup')}>Make Pickup</button>}
              {u.role !== 'admin' && <button className="px-3 py-1 bg-yellow-600 text-white rounded" onClick={()=>promoteUser(u.id, 'admin')}>Make Admin</button>}
            </div>
          </div>
        ))}
      </section>

      <AdminAnalytics />
    </div>
  );
}
