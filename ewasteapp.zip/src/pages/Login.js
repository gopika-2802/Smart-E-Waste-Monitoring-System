
import React, { useState } from 'react';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth, db } from '../firebase/firebaseConfig';
import { doc, getDoc } from 'firebase/firestore';
import { useNavigate, Link } from 'react-router-dom';

export default function Login(){
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handle = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const cred = await signInWithEmailAndPassword(auth, email, password);
      const userRef = doc(db, 'users', cred.user.uid);
      const snap = await getDoc(userRef);
      if (!snap.exists()) {
        alert('Profile not found. Contact admin.');
        setLoading(false);
        return;
      }
      const role = snap.data().role;
      if (role === 'admin') navigate('/admin');
      else if (role === 'pickup') navigate('/pickup');
      else navigate('/user');
    } catch (err) {
      alert(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <form onSubmit={handle} className="bg-white p-8 rounded-lg shadow-md w-96">
        <h2 className="text-2xl font-bold mb-4 text-green-600">E-Waste Login</h2>
        <input className="w-full mb-3 p-2 border rounded" placeholder="Email" type="email" value={email} onChange={e=>setEmail(e.target.value)} required />
        <input className="w-full mb-3 p-2 border rounded" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} required />
        <button className="w-full bg-green-600 text-white py-2 rounded" disabled={loading}>{loading?'Logging...':'Login'}</button>
        <p className="mt-3 text-sm">Don't have account? <Link to="/signup" className="text-green-600">Sign up</Link></p>
      </form>
    </div>
  );
}
