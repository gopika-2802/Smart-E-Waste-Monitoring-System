
import React, { useState, useEffect } from 'react';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { db, auth } from '../firebase/firebaseConfig';
import { onAuthStateChanged } from 'firebase/auth';
import { useNavigate } from 'react-router-dom';

export default function SubmitEwaste(){
  const [type, setType] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(()=>{
    const unsub = onAuthStateChanged(auth, (u)=> setUser(u));
    return unsub;
  }, []);

  const handle = async (e) => {
    e.preventDefault();
    if (!user) return alert('Login first');
    try {
      await addDoc(collection(db, 'ewasteSubmissions'), {
        userId: user.uid,
        email: user.email,
        ewasteType: type,
        quantity: Number(quantity),
        address,
        phone,
        status: 'Pending',
        pickupPersonId: '',
        pickupPersonName: '',
        createdAt: serverTimestamp()
      });
      alert('Submitted!');
      navigate('/user');
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="p-8 max-w-lg mx-auto">
      <h2 className="text-xl font-bold mb-4">Submit E-Waste</h2>
      <form onSubmit={handle} className="bg-white p-6 rounded shadow">
        <input className="w-full mb-3 p-2 border rounded" placeholder="E-waste Type" value={type} onChange={e=>setType(e.target.value)} required />
        <input className="w-full mb-3 p-2 border rounded" type="number" min="1" placeholder="Quantity" value={quantity} onChange={e=>setQuantity(e.target.value)} required />
        <input className="w-full mb-3 p-2 border rounded" placeholder="Address" value={address} onChange={e=>setAddress(e.target.value)} required />
        <input className="w-full mb-3 p-2 border rounded" placeholder="Phone" value={phone} onChange={e=>setPhone(e.target.value)} required />
        <button className="bg-green-600 text-white px-4 py-2 rounded">Submit</button>
      </form>
    </div>
  );
}
