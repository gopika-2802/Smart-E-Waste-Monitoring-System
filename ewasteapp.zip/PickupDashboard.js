import React, { useEffect, useState } from 'react';
import { doc, updateDoc, collection, query, where, onSnapshot } from 'firebase/firestore';
import { auth, db } from '../firebase/firebaseConfig';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { FaUserCircle } from 'react-icons/fa';

export default function PickupDashboard() {
  const [jobs, setJobs] = useState([]);
  const [pickupProfile, setPickupProfile] = useState({ name: '', email: '' });
  const [pickupId, setPickupId] = useState(null);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      if (u) {
        setPickupId(u.uid);
        setPickupProfile({
          name: u.displayName || "Pickup Person",
          email: u.email
        });
      }
    });
    return unsub;
  }, []);

  useEffect(() => {
    if (!pickupId) return;

    const q = query(
      collection(db, 'ewasteSubmissions'),
      where('pickupPersonId', '==', pickupId)
    );

    const unsub = onSnapshot(q, (snap) => {
      setJobs(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    return unsub;
  }, [pickupId]);

  const markCollected = async (id) => {
    await updateDoc(doc(db, 'ewasteSubmissions', id), {
      status: 'Collected'
    });
    alert("Marked as Collected");
  };

  const handleLogout = async () => {
    if (window.confirm("Logout?")) {
      await signOut(auth);
      window.location.href = "/";
    }
  };

  return (
    <div className="p-8">
      
      {/* Profile */}
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-3">
          <FaUserCircle className="text-4xl text-gray-600" />
          <div>
            <h1 className="text-2xl font-bold">{pickupProfile.name}</h1>
            <p className="text-gray-600">{pickupProfile.email}</p>
          </div>
        </div>
        <button onClick={handleLogout} className="bg-red-500 text-white px-4 py-2 rounded">
          Logout
        </button>
      </div>

      {jobs.length === 0 ? (
        <p>No assigned tasks</p>
      ) : (
        jobs.map(j => (
          <div key={j.id} className="bg-white p-4 rounded shadow mb-3">
            <p><strong>User Email:</strong> {j.email}</p>
            <p><strong>Type:</strong> {j.ewasteType}</p>
            <p><strong>Quantity:</strong> {j.quantity}</p>
            <p><strong>Address:</strong> {j.address}</p>
            <p><strong>Phone:</strong> <a href={`tel:${j.phone}`} className="text-blue-600">{j.phone}</a></p>
            <p><strong>Status:</strong> {j.status}</p>

            {j.status !== 'Collected' && (
              <button
                onClick={() => markCollected(j.id)}
                className="mt-2 bg-green-600 text-white px-3 py-1 rounded"
              >
                Mark Collected
              </button>
            )}
          </div>
        ))
      )}
    </div>
  );
}
